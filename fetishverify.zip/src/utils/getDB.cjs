// @ts-check
const { QuickDB } = require('quick.db');
const db = new QuickDB();

module.exports = db;