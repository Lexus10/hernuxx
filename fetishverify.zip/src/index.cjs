[
	require('./bot.cjs'),
	require('./server.cjs'),
].forEach((cmd) => cmd.start());